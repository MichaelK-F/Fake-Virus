V1.0
Fake virus by: Michael Kwiecien-Fisher(michael@wandoo.ca)

To exit fullscreen in the program press f11 or Alt + enter

Please use this program responsobly. I am not responseble for any wasted time or any damage to computers and stuff.

I also promise this will not kill your computer :)