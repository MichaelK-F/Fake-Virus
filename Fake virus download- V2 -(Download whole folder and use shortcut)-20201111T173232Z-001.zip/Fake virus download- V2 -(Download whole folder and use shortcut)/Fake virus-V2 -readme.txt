V2.0
Fake virus by: Michael Kwiecien-Fisher(michael@wandoo.ca)

To exit fullscreen in the program press f11 or Alt + enter

"setup.bat" is the file that "Guess What!" uses to work so they need to be in the same place eg. if "setup.bat" is in desktop 'Guess What" has to be there to not hidden in a sepeate folder.

Please use this program responsobly. I am not responseble for any wasted time or any damage to computers and stuff.

I also promise this will not kill your computer :)


New in this version:
    when the program prints random numbers they change colors